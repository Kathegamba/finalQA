
public class Permission {
    public static boolean canDrive(int age) {
        int drivingAge = 16;
        return age >= drivingAge;
    }
}





