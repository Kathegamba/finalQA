import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PermissionTest {

    @Test
    void underAgeToDrive() {
        boolean condition = Permission.canDrive(15);
        assertFalse(condition, "Test failed: Ages under 16 cannot drive.");
    }

    @Test
    void minimumAgeToDrive() {
        boolean condition = Permission.canDrive(16);
        assertTrue(condition, "Test passed: The minimum age to drive is 16 years old.");
    }

    @Test
    void validAgeToDrive() {
        boolean condition = Permission.canDrive(17);
        assertTrue(condition, "Test passed: Ages above 16 are allowed to drive.");
    }

    @Test
    void invalidZeroAgeToDrive() {
        boolean condition = Permission.canDrive(0);
        assertFalse(condition, "Test: failed: Age cannot be zero.");
    }

    @Test
    void invalidNegativeAgeToDrive() {
        boolean condition = Permission.canDrive(-16);
        assertFalse(condition, "Test: failed: Age should be a positive number.");
    }

    @Test
    void requirementAgeToDriveForSeniors () {
        boolean condition = Permission.canDrive(70);
        assertTrue(condition, "WA does not have a legal age limit for driving, " +
                "however people over 70 is required to renew their license and get a vision test with each renewal.");
    }
}


