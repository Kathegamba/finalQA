package testCasesSelenium;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class testCases {
    WebDriver driver;
    WebDriverWait wait;

    @Before
    public void launchWebsite() {
        driver = new ChromeDriver();
        driver.navigate().to("https://letsusedata.com");
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }

    @Test
    public void unsuccessfulLogin() {
        // Finds the box username
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        By usernameBox = By.id("txtUser");
        WebElement username = driver.findElement(usernameBox);
        username.sendKeys("test1");

        // Enter password
        By passwordBox = By.id("txtPassword");
        WebElement password = driver.findElement(passwordBox);
        password.sendKeys("test1234");

        // Click button login
        By loginButton = By.id("javascriptLogin");
        WebElement element = driver.findElement(loginButton);
        element.click();

        WebElement messageErrorPassword = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("lblMessage")));
        assertTrue("Password was incorrect.", messageErrorPassword.isDisplayed());

        driver.quit();
    }

    @Test
    public void successfulLogin() {
        // Finds the box to type the username
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        By usernameBox = By.id("txtUser");
        WebElement username = driver.findElement(usernameBox);
        username.sendKeys("test1");

        // Enter password
        By passwordBox = By.id("txtPassword");
        WebElement password = driver.findElement(passwordBox);
        password.sendKeys("Test12456");

        // Click button login
        By loginButton = By.id("javascriptLogin");
        WebElement element = driver.findElement(loginButton);
        element.click();

        WebElement goodLoginSite = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("26CourseTitle")));
        assertTrue("Successful Login. The 'Feedback Course 1' is now displaying.", goodLoginSite.isDisplayed());

        driver.quit();
    }

}
